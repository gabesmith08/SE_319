README.txt
----The project file was named "messenger." and by the way, my middle name is Gabriel and I go by Gabe, so it says Gabe in the console output instead of Richard! So First you're going to want to run Server.java 
Then, you can run Client.java to connect the first client.
 Once you open a client, type your name, then click enter. Then you can start sending messages to the server and everyone connected to it. Run the Client 2 to be able to chat with Client 1.
