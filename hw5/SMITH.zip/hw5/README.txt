README.txt
---- To start the TicTacToe program go ahead and open the Project5 project in eclipse. go into the ticTacToe package and click on the TicTacMain.java program. Run as java application. Then a window will pop up and you can play a game of TicTacToe with whoever is next to you, Enjoy!
